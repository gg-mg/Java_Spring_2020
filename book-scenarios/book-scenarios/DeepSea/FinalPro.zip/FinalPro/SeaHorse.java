import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *  SeaHorse swim so slowly so that it is chanllenge for them to get the food,
 *  and, they have no stomach, thus they needs to eat almost constantly, 
 *  also can only eat somthing like small fish or crustaceans.
 *  
 *  This subclass has 4 private image ,two method, also using keyboard for
 *  interaction by user.
 *  
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SeaHorse extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    private GreenfootImage image3;
    private GreenfootImage image4;
    /**
     * Create a sea horse and initialize its three images.
     */
    public SeaHorse()
    {
        image1 = new GreenfootImage("sea-horse.png");
        image2 = new GreenfootImage("sea-horseB.png");
        image3 = new GreenfootImage("seaFlip.png");
        image4 = new GreenfootImage("seaPink.png");
    }
    
    /**
     * Act - move when cursor keys are pressed.
     */
    public void act() 
    {
        checkKeyPress();
        checkCollision();
    }  
    
    /**
     * Check whether a keyboard key has been pressed and react if it has.
     */
    public void checkKeyPress()
    {
     if(Greenfoot.isKeyDown("up"))
        {
            setLocation(getX(), getY()-2);
        }
        
     if (Greenfoot.isKeyDown("down")) 
        {
            setLocation(getX(), getY()+2);
        }
        
     if (Greenfoot.isKeyDown("right")) 
        {
            setLocation(getX()+2, getY());
        }
        
     if (Greenfoot.isKeyDown("left")) 
        {
            setLocation(getX()-2, getY());
        }
        
     if(Greenfoot.isKeyDown("space"))//switch another iamge.
        {
            if(getImage()==image1)
        {
            setImage(image3);
        }
        else
        {
            setImage(image1);
        }
    }
}
    
/**
     * Check whether the sea horse catch the fish or crab. 
     * Remove fish or crab.
     */
    private void checkCollision()
    {
        if(isTouching(Fish.class))
        {
            MyWorld myNewWorld = (MyWorld)getWorld();
            GreenfootSound catchSong = myNewWorld.getCatchSong();
            catchSong.play();
            setImage("seaHo.png");
            int aNB=myNewWorld.getNumberOfFishTouched();
            aNB++;
            myNewWorld.setNumberOfFishTouched(aNB);
            myNewWorld.addScore(1);
            myNewWorld.showName();
            removeTouching(Fish.class);
        }
        
        if(isTouching(Crab.class))
        {
            MyWorld myNewWorld = (MyWorld)getWorld();
            GreenfootSound catchSong = myNewWorld.getCatchSong();
            catchSong.play();
            setImage("seaH.png");
            int aNB=myNewWorld.getNumberOfCrabTouched();
            aNB++;
            myNewWorld.setNumberOfCrabTouched(aNB);
            myNewWorld.addScore(2);
            myNewWorld.showName();
            removeTouching(Crab.class);
        }
    }
    
    
    
}
